/**
 * EsterilMed · Carro de Pedido - Backend (Google Apps Script)
 * -------------------------------------------------------------
 * VERSIÓN API: este script YA NO muestra la página. Solo guarda y entrega
 * datos en formato JSON. La página (carrito-github.html) vive en GitHub
 * Pages y le habla a este script por internet (fetch).
 *
 * Ver INSTRUCCIONES_INSTALACION.md para los pasos completos.
 *
 * IMPORTANTE si ya habías instalado una versión anterior con columna "Area":
 * borra las pestañas "Carritos", "Envios" y "Recepciones" de tu Hoja de Cálculo
 * antes de usar esta versión, para que el sistema las vuelva a crear con la
 * estructura nueva (ya no separa por área, ahora es por persona que solicita).
 */

const SS = SpreadsheetApp.getActiveSpreadsheet();

// ---------------- PUNTOS DE ENTRADA (API) ----------------

function jsonOutput_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  try {
    const action = e.parameter.action;
    let result;
    switch (action) {
      case 'getCarritoPersona': result = getCarritoPersona(e.parameter.week, e.parameter.solicitante); break;
      case 'getConsolidado': result = getConsolidado(e.parameter.week); break;
      case 'getEnvio': result = getEnvio(e.parameter.week); break;
      case 'getRecepcion': result = getRecepcion(e.parameter.week); break;
      case 'getHistorial': result = getHistorial(); break;
      case 'getEstadisticas': result = getEstadisticas(); break;
      default: result = { error: 'Acción no reconocida: ' + action };
    }
    return jsonOutput_(result);
  } catch (err) {
    return jsonOutput_({ error: String(err) });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action;
    let result;
    switch (action) {
      case 'submitCarrito': result = submitCarrito(body.week, body.solicitante, body.items); break;
      case 'marcarEnviado': result = marcarEnviado(body.week); break;
      case 'guardarRecepcion': result = guardarRecepcion(body.week, body.items); break;
      default: result = { error: 'Acción no reconocida: ' + action };
    }
    return jsonOutput_(result);
  } catch (err) {
    return jsonOutput_({ error: String(err) });
  }
}

function getSheet_(name, headers) {
  let sh = SS.getSheetByName(name);
  if (!sh) {
    sh = SS.insertSheet(name);
    sh.appendRow(headers);
    sh.setFrozenRows(1);
  }
  return sh;
}

function sheetToObjects_(sh) {
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0];
  return values.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
}

function monthKey_(weekIso) {
  return weekIso.substring(0, 7); // "YYYY-MM"
}

// ---------------- CARRITOS (pedido consolidado, por persona) ----------------
// Columnas: Semana | Solicitante | Insumo | Unidad | Cantidad | Actualizado

function submitCarrito(week, solicitante, items) {
  const sh = getSheet_('Carritos', ['Semana', 'Solicitante', 'Insumo', 'Unidad', 'Cantidad', 'Actualizado']);
  const data = sh.getDataRange().getValues();
  const solic = (solicitante || '(sin nombre)').trim().toLowerCase();
  for (let i = data.length - 1; i >= 1; i--) {
    if (String(data[i][0]) === String(week) && String(data[i][1]).trim().toLowerCase() === solic) {
      sh.deleteRow(i + 1);
    }
  }
  const now = new Date();
  items.forEach(it => {
    sh.appendRow([week, solicitante || '(sin nombre)', it.n, it.u || '', it.q, now]);
  });
  return { ok: true };
}

function getCarritoPersona(week, solicitante) {
  const sh = getSheet_('Carritos', ['Semana', 'Solicitante', 'Insumo', 'Unidad', 'Cantidad', 'Actualizado']);
  const solic = (solicitante || '').trim().toLowerCase();
  const rows = sheetToObjects_(sh).filter(r => String(r.Semana) === String(week) && String(r.Solicitante).trim().toLowerCase() === solic);
  if (rows.length === 0) return null;
  return { items: rows.map(r => ({ n: r.Insumo, q: r.Cantidad, u: r.Unidad })) };
}

function getConsolidado(week) {
  const sh = getSheet_('Carritos', ['Semana', 'Solicitante', 'Insumo', 'Unidad', 'Cantidad', 'Actualizado']);
  const rows = sheetToObjects_(sh).filter(r => String(r.Semana) === String(week));
  const solicitantes = [...new Set(rows.map(r => r.Solicitante))];
  const consolidado = {};
  rows.forEach(r => {
    if (!consolidado[r.Insumo]) consolidado[r.Insumo] = { q: 0, quien: [], unit: r.Unidad };
    consolidado[r.Insumo].q += Number(r.Cantidad) || 0;
    if (!consolidado[r.Insumo].quien.includes(r.Solicitante)) consolidado[r.Insumo].quien.push(r.Solicitante);
  });
  return { consolidado: consolidado, solicitantes: solicitantes };
}

// ---------------- ENVIO A BODEGA ----------------

function marcarEnviado(week) {
  const sh = getSheet_('Envios', ['Semana', 'Enviado', 'Fecha']);
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(week)) {
      sh.getRange(i + 1, 2, 1, 2).setValues([[true, new Date()]]);
      return { ok: true };
    }
  }
  sh.appendRow([week, true, new Date()]);
  return { ok: true };
}

function getEnvio(week) {
  const sh = getSheet_('Envios', ['Semana', 'Enviado', 'Fecha']);
  const rows = sheetToObjects_(sh).filter(r => String(r.Semana) === String(week));
  if (rows.length === 0) return null;
  return { enviado: rows[0].Enviado, fecha: rows[0].Fecha };
}

// ---------------- RECEPCION (lo que llegó vs lo pedido) ----------------

function guardarRecepcion(week, items) {
  const sh = getSheet_('Recepciones', ['Semana', 'Insumo', 'Pedido', 'Recibido', 'Fecha']);
  const data = sh.getDataRange().getValues();
  for (let i = data.length - 1; i >= 1; i--) {
    if (String(data[i][0]) === String(week)) sh.deleteRow(i + 1);
  }
  const now = new Date();
  items.forEach(it => {
    sh.appendRow([week, it.n, it.pedido, it.recibido === null || it.recibido === undefined ? '' : it.recibido, now]);
  });
  return { ok: true };
}

function getRecepcion(week) {
  const sh = getSheet_('Recepciones', ['Semana', 'Insumo', 'Pedido', 'Recibido', 'Fecha']);
  const rows = sheetToObjects_(sh).filter(r => String(r.Semana) === String(week));
  if (rows.length === 0) return null;
  return {
    items: rows.map(r => ({ n: r.Insumo, pedido: r.Pedido, recibido: r.Recibido === '' ? null : r.Recibido })),
    fecha: rows[0].Fecha
  };
}

// ---------------- HISTORIAL ----------------

function getHistorial() {
  const carritos = sheetToObjects_(getSheet_('Carritos', ['Semana', 'Solicitante', 'Insumo', 'Unidad', 'Cantidad', 'Actualizado']));
  const envios = sheetToObjects_(getSheet_('Envios', ['Semana', 'Enviado', 'Fecha']));
  const recepciones = sheetToObjects_(getSheet_('Recepciones', ['Semana', 'Insumo', 'Pedido', 'Recibido', 'Fecha']));
  const weeks = new Set();
  carritos.forEach(r => weeks.add(String(r.Semana)));
  envios.forEach(r => weeks.add(String(r.Semana)));
  recepciones.forEach(r => weeks.add(String(r.Semana)));

  const totalsByWeek = {};
  carritos.forEach(r => {
    totalsByWeek[r.Semana] = (totalsByWeek[r.Semana] || 0) + (Number(r.Cantidad) || 0);
  });

  return Array.from(weeks).sort().reverse().map(w => {
    const env = envios.find(r => String(r.Semana) === w);
    const rec = recepciones.filter(r => String(r.Semana) === w);
    let estado = 'Sin pedido';
    if (env && env.Enviado) estado = 'Enviado a bodega';
    if (rec.length > 0 && rec.some(r => r.Recibido !== '' && r.Recibido !== null && r.Recibido !== undefined)) {
      const falt = rec.some(r => Number(r.Recibido || 0) < Number(r.Pedido));
      estado = falt ? 'Recibido con diferencias' : 'Recibido completo';
    }
    return { semana: w, estado: estado, totalUnidades: totalsByWeek[w] || 0 };
  });
}

// ---------------- ESTADISTICAS (para bajar costos) ----------------

function getEstadisticas() {
  const carritos = sheetToObjects_(getSheet_('Carritos', ['Semana', 'Solicitante', 'Insumo', 'Unidad', 'Cantidad', 'Actualizado']));

  const totalPorInsumo = {};
  carritos.forEach(r => {
    const q = Number(r.Cantidad) || 0;
    totalPorInsumo[r.Insumo] = (totalPorInsumo[r.Insumo] || 0) + q;
  });
  const topInsumos = Object.entries(totalPorInsumo)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .map(([n, q]) => ({ n: n, q: q }));

  const totalPorSemana = {};
  carritos.forEach(r => {
    const q = Number(r.Cantidad) || 0;
    totalPorSemana[r.Semana] = (totalPorSemana[r.Semana] || 0) + q;
  });
  const semanas = Object.keys(totalPorSemana).sort();
  const tendenciaSemanal = semanas.map(s => ({ semana: s, total: totalPorSemana[s] }));

  const meses = [...new Set(carritos.map(r => monthKey_(String(r.Semana))))].sort();
  let mesActual = null, mesAnterior = null;
  if (meses.length >= 1) mesActual = meses[meses.length - 1];
  if (meses.length >= 2) mesAnterior = meses[meses.length - 2];

  const porInsumoMes = {};
  carritos.forEach(r => {
    const m = monthKey_(String(r.Semana));
    const q = Number(r.Cantidad) || 0;
    if (!porInsumoMes[r.Insumo]) porInsumoMes[r.Insumo] = {};
    porInsumoMes[r.Insumo][m] = (porInsumoMes[r.Insumo][m] || 0) + q;
  });

  const comparacionMensual = [];
  if (mesActual && mesAnterior) {
    Object.keys(porInsumoMes).forEach(insumo => {
      const actual = porInsumoMes[insumo][mesActual] || 0;
      const anterior = porInsumoMes[insumo][mesAnterior] || 0;
      if (actual === 0 && anterior === 0) return;
      let variacionPct = null;
      if (anterior > 0) variacionPct = Math.round(((actual - anterior) / anterior) * 100);
      comparacionMensual.push({ n: insumo, actual: actual, anterior: anterior, variacionPct: variacionPct });
    });
    comparacionMensual.sort((a, b) => {
      const av = a.variacionPct === null ? -Infinity : a.variacionPct;
      const bv = b.variacionPct === null ? -Infinity : b.variacionPct;
      return bv - av;
    });
  }

  return {
    topInsumos: topInsumos,
    tendenciaSemanal: tendenciaSemanal,
    mesActual: mesActual,
    mesAnterior: mesAnterior,
    comparacionMensual: comparacionMensual
  };
}
