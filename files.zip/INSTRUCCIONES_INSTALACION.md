# Cómo instalar el Carro de Pedido (GitHub Pages + Google Apps Script)

Con este esquema:
- **Google Apps Script** guarda los datos (los pedidos, envíos, recepciones) en una Hoja de Google. Ya no muestra ninguna página — solo responde datos.
- **GitHub Pages** muestra la página del carrito (el archivo `carrito-github.html`), igual que hiciste con la Academia EsterilMed.

> **Si ya habías instalado la versión anterior (todo dentro de Apps Script):** no hay problema en cambiar. Vas a repetir el Paso 2 con el código nuevo (es más corto, ya no sirve HTML) y vas a borrar el archivo `Index` de Apps Script si existe, porque ya no se usa ahí.

---

## Parte A — El motor de datos (Google Apps Script)

### Paso 1 — Crear o reutilizar la Hoja de Cálculo
1. Si no la tienes: ve a https://sheets.google.com y crea una hoja nueva llamada **"Carro de Pedido EsterilMed"**.
2. Si ya la tenías de un intento anterior: ábrela. Si tiene pestañas `Carritos`, `Envios` o `Recepciones` de la versión vieja (con columna "Area"), bórralas — el sistema las vuelve a crear solas con la estructura correcta.

### Paso 2 — Pegar el código
1. Menú **Extensiones > Apps Script**.
2. Borra todo el contenido de `Código.gs`.
3. Copia TODO el contenido del archivo **Code.gs** que te entregué y pégalo ahí.
4. Guarda (Ctrl+S).
5. Si existe un archivo llamado `Index` (de la versión anterior) en la lista de archivos de la izquierda, bórralo con el menú de los 3 puntos — ya no se usa.

### Paso 3 — Publicar como Aplicación Web (API)
1. Botón azul **Implementar > Nueva implementación**.
2. Ícono de engranaje ⚙️ > **Aplicación web**.
3. Configura:
   - **Ejecutar como:** Yo (tu cuenta)
   - **Quién tiene acceso:** Cualquier usuario con el enlace
4. **Implementar**. Autoriza los permisos si te los pide (Avanzado > Ir a... si sale advertencia de "no verificada" — es normal, es tu propio script).
5. Copia la **URL de la aplicación web**. Debe verse así:
   `https://script.google.com/macros/s/AKfycb.../exec`
   **Guarda esta URL, la necesitas en el Paso 5.**

---

## Parte B — La página (GitHub Pages)

### Paso 4 — Preparar el archivo
1. Abre el archivo **carrito-github.html** que te entregué.
2. Busca la línea (cerca del principio del `<script>`):
   ```
   const API_URL = "PEGA_AQUI_TU_URL_DE_APPS_SCRIPT";
   ```
3. Reemplaza el texto `PEGA_AQUI_TU_URL_DE_APPS_SCRIPT` por la URL que copiaste en el Paso 3, dejando las comillas. Debe quedar así (con tu URL real):
   ```
   const API_URL = "https://script.google.com/macros/s/AKfycb.../exec";
   ```
4. Guarda el archivo.

### Paso 5 — Subirlo a tu repositorio de GitHub Pages
1. Entra a tu repositorio (el mismo que usas para la Academia EsterilMed, o uno nuevo si prefieres separarlo).
2. Sube el archivo `carrito-github.html` (Add file > Upload files).
3. Si quieres que quede en una dirección simple, puedes renombrarlo a `carrito.html` o incluso `index.html` si le dedicas un repositorio propio.
4. Confirma el cambio (commit).
5. Ve a **Settings > Pages** de ese repositorio y confirma que GitHub Pages esté activado (rama `main`, carpeta raíz).
6. Tu carrito va a quedar disponible en una URL como:
   `https://tu-usuario.github.io/tu-repositorio/carrito.html`

### Paso 6 — Compartir el link
Envía esa URL de GitHub Pages (no la de Apps Script) a quienes hacen pedidos. Esa es la que se abre desde el celular, se puede "Agregar a pantalla de inicio" (iPhone: compartir > Agregar a inicio; Android: menú > Agregar a pantalla principal), y queda como un ícono más.

---

## Cómo probar que quedó bien conectado
1. Abre la URL de GitHub Pages.
2. Escribe un nombre, agrega un insumo de prueba, toca **Enviar pedido**.
3. Si aparece "Pedido enviado ✓" quedó funcionando.
4. Si aparece un error, revisa:
   - Que copiaste bien la URL completa de Apps Script (termina en `/exec`, no en `/dev`).
   - Que en el Paso 3 elegiste "Cualquier usuario con el enlace".
   - Abre esa URL de Apps Script directo en el navegador con `?action=getHistorial` al final (ej: `https://script.google.com/macros/s/AKfycb.../exec?action=getHistorial`) — debería mostrarte un texto tipo `[]` o con datos, no una página de error.

## Si más adelante cambias el código de Apps Script
Cada cambio en `Code.gs` necesita una **nueva versión** del despliegue para que se vea reflejado:
1. **Implementar > Gestionar implementaciones**.
2. Lápiz ✏️ de la implementación activa > **Nueva versión** > **Implementar**.
(La URL no cambia, así que no hay que tocar nada en el HTML de GitHub al hacer esto.)

## Dónde quedan los datos
Todo se guarda en tu Hoja de Cálculo "Carro de Pedido EsterilMed", en las pestañas `Carritos`, `Envios` y `Recepciones` (se crean solas). Es una hoja de Google normal: la puedes abrir, filtrar y respaldar cuando quieras.
